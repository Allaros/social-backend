import { Injectable, NotFoundException } from '@nestjs/common';
import { LikeService } from '../services/like.service';
import { DataSource } from 'typeorm';
import { PostCounterService } from '@app/modules/post-counters/post-counter.service';
import { LikeTargetType } from '../types/like.interface';
import { PostCommentsService } from '@app/modules/post-comments/services/post-comments.service';

@Injectable()
export class DeleteLikeUseCase {
  constructor(
    private readonly likeService: LikeService,
    private readonly dataSource: DataSource,
    private readonly postCounterService: PostCounterService,
    private readonly commentService: PostCommentsService,
  ) {}

  async execute(
    targetId: number,
    currentProfileId: number,
    targetType: LikeTargetType,
  ) {
    const existingLike = await this.likeService.findByIds(
      targetId,
      currentProfileId,
      targetType,
    );

    if (!existingLike) throw new NotFoundException('Не удалось найти лайк');

    await this.dataSource.transaction(async (manager) => {
      await this.likeService.delete(
        targetId,
        currentProfileId,
        targetType,
        manager,
      );
      if (targetType === LikeTargetType.POST) {
        await this.postCounterService.updateCounters(
          targetId,
          { likesCount: -1 },
          manager,
        );
      } else {
        await this.commentService.decrementLikes(targetId, manager);
      }
    });

    return { success: true };
  }
}
