import {
  IsNumber,
  IsNumberString,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateCommentDto {
  @IsString()
  body: string;

  @IsNumber()
  postId: number;

  @IsNumber()
  @IsOptional()
  parentId?: number;
}

export class EditCommentDto {
  @IsNumber()
  postId: number;

  @IsString()
  body: string;
}

export class GetCommentsQueryDto {
  @IsOptional()
  @IsString()
  cursor?: string;

  @IsOptional()
  @IsNumberString()
  limit?: string;
}
