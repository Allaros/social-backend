import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PostCommentsService } from '../services/post-comments.service';
import { DataSource } from 'typeorm';
import { PostCounterService } from '@app/modules/post-counters/post-counter.service';

@Injectable()
export class DeleteCommentUseCase {
  constructor(
    private readonly commentService: PostCommentsService,
    private readonly dataSource: DataSource,
    private readonly postCounterService: PostCounterService,
  ) {}

  async execute(profileId: number, commentId: number) {
    const existingComment = await this.commentService.findById(commentId);

    if (!existingComment) throw new NotFoundException('Комментарий не найден');

    if (existingComment.deletedAt)
      throw new BadRequestException('Комментарий уже удален');

    if (existingComment.profileId !== profileId)
      throw new ForbiddenException('Вы не являетесь автором комментария');

    const postId = existingComment.postId;

    await this.dataSource.transaction(async (manager) => {
      const isRoot = !existingComment.parentId;
      const hasReplies = existingComment.repliesCount > 0;

      if (hasReplies) {
        await this.commentService.delete(commentId, manager);
      } else {
        await this.commentService.hardDelete(commentId, manager);
      }

      if (isRoot) {
        await this.postCounterService.updateCounters(
          postId,
          { commentsCount: -1 },
          manager,
        );
      } else {
        await this.commentService.decrementReplies(
          existingComment.parentId!,
          existingComment.postId,
          manager,
        );

        const parent = await this.commentService.findById(
          existingComment.parentId!,
          postId,
          manager,
        );

        if (parent && parent.deletedAt && parent.repliesCount === 1) {
          await this.commentService.hardDelete(parent.id, manager);
        }
      }
    });

    return { success: true };
  }
}
