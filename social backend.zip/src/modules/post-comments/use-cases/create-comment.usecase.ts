import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import { PostCommentsService } from '../services/post-comments.service';
import { PostCounterService } from '@app/modules/post-counters/post-counter.service';
import { PostService } from '@app/modules/post/services/post.service';

@Injectable()
export class CreateCommentUseCase {
  constructor(
    private readonly dataSource: DataSource,
    private readonly commentService: PostCommentsService,
    private readonly postCounterService: PostCounterService,
    private readonly postService: PostService,
  ) {}

  async execute(commentPayload: {
    body: string;
    profileId: number;
    postId: number;
    parentId?: number;
  }) {
    const { body, postId, profileId, parentId } = commentPayload;

    let normalizedParentId: number | null = null;

    const existingPost = await this.postService.findById(postId);

    if (!existingPost) throw new NotFoundException('Пост не найден');
    if (!existingPost.allowComments)
      throw new ForbiddenException(
        'Автор поста ограничл доступ к комментариям',
      );

    const comment = await this.dataSource.transaction(async (manager) => {
      if (parentId) {
        const parent = await this.commentService.findById(
          parentId,
          postId,
          manager,
        );

        if (!parent)
          throw new NotFoundException('Комментарий для ответа не найден');

        if (parent.deletedAt)
          throw new BadRequestException(
            'Нельзя ответить на удаленный комментарий',
          );

        normalizedParentId = parent.parentId ?? parent.id;
      }
      const newComment = await this.commentService.create(
        body,
        profileId,
        postId,
        normalizedParentId,
        manager,
      );

      if (!normalizedParentId) {
        await this.postCounterService.updateCounters(
          postId,
          {
            commentsCount: 1,
          },
          manager,
        );
      } else {
        await this.commentService.incrementReplies(
          normalizedParentId,
          postId,
          manager,
        );
      }

      return newComment;
    });

    return comment;
  }
}
