import { Injectable } from '@nestjs/common';
import { ProfileService } from '../profile/profile.service';

@Injectable()
export class SearchService {
  constructor(private readonly profileService: ProfileService) {}
  async dropdownSearch(query: string) {
    const normalizedQuery = query.trim();
    if (!normalizedQuery || normalizedQuery.length < 2) {
      return { data: [], total: null };
    }
    const limit = 4;

    const [profiles] = await Promise.all([
      this.profileService.findProfiles(query, limit),
    ]);

    return {
      profiles: profiles.data,
    };
  }

  async searchResults(
    query: string,
    type: 'profiles' | 'posts',
    limit: number = 20,
    page: number,
  ) {
    if (type === 'profiles') {
      return this.profileService.findProfiles(query, limit, page);
    }
    if (type === 'posts') {
      return { data: [], total: null };
    }
  }
}
