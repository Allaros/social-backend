import {
  Body,
  Controller,
  Delete,
  Param,
  ParseIntPipe,
  Post,
  Put,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { JwtAuthGuard } from '../../auth/guards/auth.guard';
import { EmailVerifiedGuard } from '../../auth/guards/email-verified.guard';
import { FilesInterceptor } from '@nestjs/platform-express';
import { CreatePostDto, EditPostDto } from '../types/post.dto';
import { CurrentUser } from '@app/shared/decorators/currentUser.decorator';
import { UserEntity } from '../../user/user.entity';
import { CreatePostUseCase } from '../use-cases/create-post.usecase';
import { HardDeletePostUseCase } from '../use-cases/hard-delete-post.usecase';
import { RecoverPostUseCase } from '../use-cases/recover-post.usecase';
import { SoftDeletePostUseCase } from '../use-cases/soft-delete-post.usecase';
import { EditPostUseCase } from '../use-cases/edit-post.usecase';

@Controller('posts')
export class PostController {
  constructor(
    private readonly createPostUseCase: CreatePostUseCase,
    private readonly hardDeletePostUseCase: HardDeletePostUseCase,
    private readonly softDeletePostUseCase: SoftDeletePostUseCase,
    private readonly recoverPostUseCase: RecoverPostUseCase,
    private readonly editPostUseCase: EditPostUseCase,
  ) {}

  @Post()
  @UseGuards(JwtAuthGuard, EmailVerifiedGuard)
  @UseInterceptors(FilesInterceptor('media'))
  create(
    @CurrentUser() user: UserEntity,
    @Body() dto: CreatePostDto,
    @UploadedFiles() media?: Express.Multer.File[],
  ) {
    return this.createPostUseCase.execute(user.profile.id, dto, media);
  }

  @Put('edit/:id')
  @UseGuards(JwtAuthGuard, EmailVerifiedGuard)
  @UseInterceptors(FilesInterceptor('media'))
  async editPost(
    @Body() dto: EditPostDto,
    @Param('id', ParseIntPipe) postId: number,
    @CurrentUser() user: UserEntity,
    @UploadedFiles() media?: Express.Multer.File[],
  ) {
    return await this.editPostUseCase.execute(
      postId,
      user.profile.id,
      dto,
      media,
    );
  }

  @Delete(':id/hard')
  @UseGuards(JwtAuthGuard, EmailVerifiedGuard)
  async postHardDelete(
    @Param('id') postId: string,
    @CurrentUser() user: UserEntity,
  ) {
    await this.hardDeletePostUseCase.execute(Number(postId), user.profile.id);

    return { success: true };
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, EmailVerifiedGuard)
  async postSoftDelete(
    @Param('id') postId: string,
    @CurrentUser() user: UserEntity,
  ) {
    await this.softDeletePostUseCase.execute(Number(postId), user.profile.id);

    return { success: true };
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard, EmailVerifiedGuard)
  async postRecover(
    @Param('id') postId: string,
    @CurrentUser() user: UserEntity,
  ) {
    const post = await this.recoverPostUseCase.execute(
      Number(postId),
      user.profile.id,
    );

    return post;
  }
}
